
using System.Collections.Generic;
using System.Text;
using Meta.XR.MRUtilityKit;
using UnityEngine;

public class ControleAcessoMR : MonoBehaviour
{
    [System.Serializable]
    public class Etiqueta
    {
        public string titulo;

        [TextArea(2, 4)]
        public string explicacao;

        [Tooltip("Posição em metros, a partir do QR Code")]
        public Vector3 posicaoLocal;

        public Vector3 rotacaoLocal;
    }

    enum Modo
    {
        Aguardando,
        QR,
        Manual
    }

    [Header("QR Code")]
    public string payloadEsperado = "CONTROLE_ACESSO_MR";

    [Header("Aparência")]
    public float tamanhoLetra = 0.003f;
    public float tamanhoLetraPainel = 0.004f;

    [Header("Ajuste fino")]
    public float velocidadeMovimento = 0.15f;
    public float velocidadeRotacao = 40f;

    [Header("Diagnóstico")]
    public bool mostrarPainel = true;

    // POSIÇÕES PROVISÓRIAS: ainda precisam ser medidas na montagem real.
    public List<Etiqueta> etiquetas = new List<Etiqueta>
    {
        new Etiqueta
        {
            titulo = "1. RC522 (leitor RFID)",
            explicacao = "Lê o cartão e\nenvia o código dele.",
            posicaoLocal = new Vector3(-0.15f, 0.10f, 0f)
        },

        new Etiqueta
        {
            titulo = "2. ESP32",
            explicacao = "Recebe o código e\ndecide se autoriza.",
            posicaoLocal = new Vector3(0f, 0.10f, 0f)
        },

        new Etiqueta
        {
            titulo = "3. LCD",
            explicacao = "Mostra o resultado:\nautorizado ou negado.",
            posicaoLocal = new Vector3(0.15f, 0.10f, 0f)
        },

        new Etiqueta
        {
            titulo = "4. Servo (porta)",
            explicacao = "Abre a porta quando\no acesso é autorizado.",
            posicaoLocal = new Vector3(0.30f, 0.10f, 0f)
        },
    };

    Font fonte;
    TextMesh painel;
    Transform raiz, ajuste;

    readonly List<TextMesh> textos = new List<TextMesh>();

    Modo modo = Modo.Aguardando;

    int passo = -1;
    int totalDetectados;

    string ultimoTipo = "(nenhum)";
    string ultimoPayload = "(nenhum)";

    float proximaAtualizacao;

    void Start()
    {
        fonte = Resources.GetBuiltinResource<Font>("LegacyRuntime.ttf");

        CriarRaizEEtiquetas();

        if (mostrarPainel)
            CriarPainel();

        AplicarCores();

        if (MRUK.Instance != null)
        {
            MRUK.Instance.SceneSettings.TrackableAdded.AddListener(OnTrackableAdded);
            MRUK.Instance.SceneSettings.TrackableRemoved.AddListener(OnTrackableRemoved);
        }
    }

    void OnDestroy()
    {
        if (MRUK.Instance != null)
        {
            MRUK.Instance.SceneSettings.TrackableAdded.RemoveListener(OnTrackableAdded);
            MRUK.Instance.SceneSettings.TrackableRemoved.RemoveListener(OnTrackableRemoved);
        }
    }

    void Update()
    {
        LerControles();
        AtualizarPainel();
    }

    // ---------- Controles ----------

    void LerControles()
    {
        if (OVRInput.GetDown(OVRInput.Button.One))
            PosicionarManual();

        if (OVRInput.GetDown(OVRInput.Button.Two) && painel != null)
            painel.gameObject.SetActive(!painel.gameObject.activeSelf);

        if (OVRInput.GetDown(OVRInput.Button.Three))
        {
            ajuste.localPosition = Vector3.zero;
            ajuste.localRotation = Quaternion.identity;
        }

        if (OVRInput.GetDown(OVRInput.Button.SecondaryIndexTrigger))
            ProximoPasso();

        if (modo == Modo.Aguardando)
            return;

        Vector2 esq = OVRInput.Get(OVRInput.Axis2D.PrimaryThumbstick);
        Vector2 dir = OVRInput.Get(OVRInput.Axis2D.SecondaryThumbstick);

        float dt = Time.deltaTime;

        ajuste.localPosition += new Vector3(
            Zona(dir.x),
            Zona(esq.y),
            Zona(dir.y)
        ) * velocidadeMovimento * dt;

        ajuste.Rotate(
            0f,
            Zona(esq.x) * velocidadeRotacao * dt,
            0f,
            Space.Self
        );
    }

    float Zona(float v)
    {
        return Mathf.Abs(v) < 0.2f ? 0f : v;
    }

    void ProximoPasso()
    {
        passo++;

        if (passo >= textos.Count)
            passo = -1;

        AplicarCores();
    }

    void AplicarCores()
    {
        for (int i = 0; i < textos.Count; i++)
        {
            if (passo < 0)
                textos[i].color = Color.white;
            else
                textos[i].color = (i == passo)
                    ? Color.yellow
                    : new Color(0.45f, 0.45f, 0.45f);
        }
    }

    Transform Cabeca()
    {
        var rig = FindFirstObjectByType<OVRCameraRig>();

        if (rig != null)
            return rig.centerEyeAnchor;

        return Camera.main != null
            ? Camera.main.transform
            : null;
    }

    void PosicionarManual()
    {
        Transform cab = Cabeca();

        if (cab == null)
            return;

        Vector3 frente = Vector3.ProjectOnPlane(
            cab.forward,
            Vector3.up
        );

        if (frente.sqrMagnitude < 0.01f)
            frente = Vector3.forward;

        frente.Normalize();

        raiz.SetParent(null, false);

        raiz.position = cab.position
            + frente * 0.6f
            + Vector3.down * 0.25f;

        raiz.rotation = Quaternion.LookRotation(
            frente,
            Vector3.up
        );

        ajuste.localPosition = Vector3.zero;
        ajuste.localRotation = Quaternion.identity;

        raiz.gameObject.SetActive(true);

        modo = Modo.Manual;
    }

    // ---------- QR Code ----------

    void OnTrackableAdded(MRUKTrackable trackable)
    {
        totalDetectados++;

        ultimoTipo = trackable.TrackableType.ToString();

        if (trackable.TrackableType != OVRAnchor.TrackableType.QRCode)
            return;

        string payload = trackable.MarkerPayloadString;

        ultimoPayload = string.IsNullOrEmpty(payload)
            ? "(vazio)"
            : payload;

        Debug.Log("QR detectado: " + payload);

        if (string.IsNullOrEmpty(payload) || payload.Trim() != payloadEsperado)
            return;

        raiz.SetParent(trackable.transform, false);

        raiz.localPosition = Vector3.zero;
        raiz.localRotation = Quaternion.identity;

        raiz.gameObject.SetActive(true);

        modo = Modo.QR;
    }

    void OnTrackableRemoved(MRUKTrackable trackable)
    {
        if (raiz != null && raiz.parent == trackable.transform)
        {
            raiz.SetParent(null, true);
            modo = Modo.Manual;
        }
    }

    // ---------- Criação dos textos ----------

    void CriarRaizEEtiquetas()
    {
        raiz = new GameObject("RaizControleAcesso").transform;

        ajuste = new GameObject("Ajuste").transform;
        ajuste.SetParent(raiz, false);

        foreach (var e in etiquetas)
        {
            var go = new GameObject("Etiqueta_" + e.titulo);

            go.transform.SetParent(ajuste, false);

            go.transform.localPosition = e.posicaoLocal;
            go.transform.localRotation = Quaternion.Euler(e.rotacaoLocal);

            textos.Add(
                ConfigurarTexto(
                    go,
                    e.titulo + "\n" + e.explicacao,
                    tamanhoLetra
                )
            );
        }

        raiz.gameObject.SetActive(false);
    }

    TextMesh ConfigurarTexto(GameObject go, string texto, float tamanho)
    {
        var tm = go.AddComponent<TextMesh>();

        tm.font = fonte;
        tm.text = texto;
        tm.fontSize = 80;
        tm.characterSize = tamanho;
        tm.anchor = TextAnchor.MiddleCenter;
        tm.alignment = TextAlignment.Center;
        tm.color = Color.white;

        go.GetComponent<MeshRenderer>().sharedMaterial = fonte.material;

        return tm;
    }

    // ---------- Painel de diagnóstico ----------

    void CriarPainel()
    {
        Transform cab = Cabeca();

        if (cab == null)
            return;

        var go = new GameObject("PainelDiagnostico");

        go.transform.SetParent(cab, false);

        go.transform.localPosition = new Vector3(
            0f,
            -0.2f,
            1.0f
        );

        painel = ConfigurarTexto(
            go,
            "iniciando...",
            tamanhoLetraPainel
        );
    }

    bool TemPermissaoCena()
    {
#if UNITY_ANDROID && !UNITY_EDITOR
        return UnityEngine.Android.Permission.HasUserAuthorizedPermission(OVRPermissionsRequester.ScenePermission);
#else
        return true;
#endif
    }

    void AtualizarPainel()
    {
        if (painel == null || Time.time < proximaAtualizacao)
            return;

        proximaAtualizacao = Time.time + 0.5f;

        var sb = new StringBuilder();

        sb.AppendLine(
            "MRUK: " + (MRUK.Instance != null ? "ok" : "NAO ENCONTRADO")
        );

        if (MRUK.Instance != null)
            sb.AppendLine(
                "QR suportado: " + (MRUK.Instance.QRCodeTrackingSupported ? "sim" : "NAO")
            );

        sb.AppendLine(
            "Permissao de cena: " + (TemPermissaoCena() ? "sim" : "NAO")
        );

        sb.AppendLine(
            "Detectados: " + totalDetectados + " | tipo: " + ultimoTipo
        );

        sb.AppendLine(
            "Ultimo texto: " + ultimoPayload
        );

        sb.AppendLine(
            "Modo: " + modo + " | passo: " + (passo < 0 ? "todos" : (passo + 1).ToString())
        );

        sb.AppendLine("A=posicionar  Gatilho dir=proximo");
        sb.AppendLine("Analogicos=ajustar  X=zerar  B=painel");

        painel.text = sb.ToString();
    }
}
